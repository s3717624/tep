package robot.ascii;

import control.Control;
import control.RobotControl;
import robot.Robot;
import robot.ascii.impl.Arm;
import robot.ascii.impl.Bar;
import robot.ascii.impl.Block;
import robot.ascii.impl.Drawable;
import robot.impl.RobotImpl;
import robot.impl.RobotInitException;

// ASCIIBot template code Programming 1 s1, 2018
// designed by Caspar, additional code by Ross
public class ASCIIBot extends AbstractASCIIBot implements Robot {

	private static final int[] BAR_HEIGHTS_DEFAULT = new int[] { 7, 3, 1, 7, 5, 3, 2 };;
	private static final int[] BLOCK_HEIGHTS_DEFAULT = new int[] { 3, 1, 2, 3, 1, 1, 1 };
	private Arm arm;
	private Bar[] bars;
	private Block[] blocks;
	private int height;
	private int width;
	private int depth;


	public static void main(String[] args) {
		new RobotControl().control(new ASCIIBot(), BAR_HEIGHTS_DEFAULT, BLOCK_HEIGHTS_DEFAULT);
	}

	// MUST CALL DEFAULT SUPERCLASS CONSTRUCTOR!
	public ASCIIBot() {
		super();
	}

	@Override
	public void init(int[] barHeights, int[] blockHeights, int height, int width, int depth) {
		// in addition to validating init params this also sets up keyboard
		// support for the ASCIIBot!

		try {
			RobotImpl.validateInitParams(this, barHeights, blockHeights, height, width, depth);
		} catch (RobotInitException e) {
			System.err.println(e.getMessage());
			System.exit(0);
		}

		this.height = height;
		this.width = width;
		this.depth = depth;

		this.initImpl();


		delayAnimation();

	}

	private void initImpl() {
		int srcCol = Control.SRC_COLUMN *Drawable.H_SCALE_FACTOR;

		bars = new Bar[BAR_HEIGHTS_DEFAULT.length]; //create bars
		blocks = new Block[BLOCK_HEIGHTS_DEFAULT.length]; //create blocks
		int bar_index = 0; 
		while (bar_index < BAR_HEIGHTS_DEFAULT.length) {
			Bar bar = new Bar((3 + bar_index), 0, BAR_HEIGHTS_DEFAULT[bar_index]);  //draw bars
			bars[bar_index] = bar;
			bar.draw(terminalFrame);
			bar_index++;
		}
		int block_index = 0;
		int sum_blockHeight = 0;
		while (block_index < BLOCK_HEIGHTS_DEFAULT.length) {
			Block block = new Block(srcCol, sum_blockHeight, BLOCK_HEIGHTS_DEFAULT[block_index]); //draw blocks
			blocks[block_index] = block;
			block.draw(terminalFrame);
			sum_blockHeight += BLOCK_HEIGHTS_DEFAULT[block_index]*Drawable.V_SCALE_FACTOR;
			block_index++;

		}
		arm = new Arm(height, width, depth); 

		arm.draw(terminalFrame); //draw the arm
	}

	@Override
	public void pick() {
		// implement methods to draw robot environment using your implementation
		// of Arm.draw(), Bar.draw() etc.
		System.out.println("pick()");
	}

	@Override
	public void drop() {
		System.out.println("drop()");
	}

	@Override
	public void up() {
		System.out.println("up()");
	}

	@Override
	public void down() {
		System.out.println("down()");
	}

	@Override
	public void contract() {
		System.out.println("contract()");
	}

	@Override
	public void extend() {
		System.out.println("extend()");
	}

	@Override
	public void lower() {
		System.out.println("lower()");
	}

	@Override
	public void raise() {
		System.out.println("raise()");
	}
}
	
