package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

public class Block implements Drawable
{
	int col;
	int row;
	int height;
	TextColor fgColor;
	TextColor bgColor;
	
	public Block(int col,int row,int height) {
		super();
		// TODO Auto-generated constructor stub
		this.bgColor = BLOCK_COLORS_BG[height-1];
		this.fgColor = BLOCK_COLORS_FG[height-1];	
		this.col =col;
		this.row =row;
		this.height=height;
		
	}
	
	@Override
	public void draw(SwingTerminalFrame terminalFrame)
	{
		int maxRow = terminalFrame.getTerminalSize().getRows() - 1;

		terminalFrame.setForegroundColor(fgColor);
		terminalFrame.setBackgroundColor(bgColor);
		
		// draw a 'bar' of height "draw_height" in middle column with scaling
		// NOTE: we translate to terminal co-ordinates where 0,0 is top left!
		//terminalFrame.setCursorPosition(0,maxRow);
		//terminalFrame.putCharacter(Drawable.BAR_CHAR);
		int rowPos = row;
		for (int blockSize = 0; blockSize < height; blockSize++)
		{
			// apply vertical and horizontal scaling by looping to draw multiple chars
			for (int rowScale = 0; rowScale < Drawable.V_SCALE_FACTOR; rowScale++)
			{
				for (int colScale = 0; colScale < Drawable.H_SCALE_FACTOR; colScale++)
				{
					terminalFrame.setCursorPosition(col + colScale, maxRow - rowPos);
					terminalFrame.putCharacter(Drawable.BLOCK_CHAR);
				}
				rowPos++;
			}
		}
		
	}
	
	public void moveUp() {
	
	 }
	 
	 public void moveLeft() {

	 }
	 
	 public void moveDown() {
	 }
	 
	 public void moveRight() {
		
	 }
}
