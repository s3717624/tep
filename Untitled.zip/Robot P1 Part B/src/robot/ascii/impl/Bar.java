package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

public class Bar implements Drawable
{
	int col;
	int row;
	int height;
	TextColor fgColor;
	TextColor bgColor;
	
	public Bar(int col,int row, int height) {
		super();
		// TODO Auto-generated constructor stub
		this.col = col *Drawable.H_SCALE_FACTOR;
		this.height = height;
		this.bgColor = Drawable.BAR_COLOR_BG;
		this.fgColor = Drawable.BAR_COLOR_FG;	

	}

	@Override
	public void draw(SwingTerminalFrame terminalFrame)
	{

		int maxRow = terminalFrame.getTerminalSize().getRows() - 1;

		terminalFrame.setForegroundColor(fgColor);
		terminalFrame.setBackgroundColor(bgColor);
		
		// draw a 'bar' of height "draw_height" in middle column with scaling
		// NOTE: we translate to terminal co-ordinates where 0,0 is top left!
		int rowPos = row;
		for (int barSize = 0; barSize < height; barSize++)
		{
			// apply vertical and horizontal scaling by looping to draw multiple chars
			for (int rowScale = 0; rowScale < Drawable.V_SCALE_FACTOR; rowScale++)
			{
				for (int colScale = 0; colScale < Drawable.H_SCALE_FACTOR; colScale++)
				{
					terminalFrame.setCursorPosition(col + colScale, maxRow - rowPos);
					terminalFrame.putCharacter(Drawable.BAR_CHAR);
				}
				rowPos++;
			}
		}
	}
}
