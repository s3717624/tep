package robot.ascii.impl;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.swing.SwingTerminalFrame;

import robot.RobotMovement;

public class Arm  implements RobotMovement, Drawable{
	private int width;
	private int depth;
	int col;
	int row;
	int height;
	TextColor fgColor;
	TextColor bgColor;

	public Arm(int height, int width, int depth) {
		super();

		// TODO Auto-generated constructor stub
		this.bgColor = ARM_COLOR_BG;
		this.fgColor = ARM_COLOR_FG;
		this.col = 0;
		this.row = 0;
		this.height = height;
		this.width = width;
		this.depth = depth;

	}


	public void draw(SwingTerminalFrame terminalFrame) {
		int maxRow = terminalFrame.getTerminalSize().getRows() - 1;

		terminalFrame.setForegroundColor(fgColor);
		terminalFrame.setBackgroundColor(bgColor);

		int rowPos = row;        //segment arm1
		for (int heightSize = 0; heightSize < height; heightSize++) {
			// apply vertical and horizontal scaling by looping to draw multiple
			// chars
			for (int rowScale = 0; rowScale < Drawable.V_SCALE_FACTOR; rowScale++) {
				for (int colScale = 0; colScale < Drawable.H_SCALE_FACTOR; colScale++) {
					terminalFrame.setCursorPosition(col + colScale, maxRow - rowPos); 
					terminalFrame.putCharacter(Drawable.ARM_CHAR);
				}
				rowPos++;
			}
		}

		int colPos = (col + 1)*Drawable.H_SCALE_FACTOR; //segment arm2
		for (int widthSize = 0; widthSize < width; widthSize++) {
			// apply vertical and horizontal scaling by looping to draw multiple
			// chars
			for (int colScale = 0; colScale < Drawable.H_SCALE_FACTOR; colScale++) {
				for (int rowScale = 0; rowScale < Drawable.V_SCALE_FACTOR; rowScale++) {
					terminalFrame.setCursorPosition(colPos, maxRow - (height*Drawable.V_SCALE_FACTOR) + 1 + rowScale);
					terminalFrame.putCharacter(Drawable.ARM_CHAR);
				}
				colPos++;
			}
		}

		int rowPos1 = maxRow - (height*Drawable.V_SCALE_FACTOR) + 1 + Drawable.V_SCALE_FACTOR;  
		
		for (int depthSize = 0; depthSize < depth; depthSize++) { //segment arm3
			// apply vertical and horizontal scaling by looping to draw multiple
			// chars
			for (int rowScale = 0; rowScale < Drawable.V_SCALE_FACTOR; rowScale++) {
				for (int colScale = 0; colScale < Drawable.H_SCALE_FACTOR; colScale++) {
					terminalFrame.setCursorPosition(colPos - Drawable.H_SCALE_FACTOR + colScale, rowPos1);
					terminalFrame.putCharacter(Drawable.ARM_CHAR);
				}
				rowPos1++;
			}
		}

	}
	

	@Override
	public void drop() {

	}

	@Override
	public void up() {
		
	}

	@Override
	public void down() {
	
	}

	@Override
	public void contract() {
		
	}

	@Override
	public void extend() {
	

	}

	@Override
	public void lower() {
	
	}

	@Override
	public void raise() {
	
	}

	@Override
	public void pick() {

	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	
}